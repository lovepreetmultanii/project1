<?php
$target_dir ="uploads/";
$target_file = $target_dir . basename($_FILES["fileupload"]["name"]);

echo "target_file" ."<br>";

$target_file_type = pathinfo($target_file_type,PATHINFO_EXTENSION);
Echo "$target_file_type" . "<br>";

$uploadOk = 1;
if(($target_file_type !="jpg") && ($target_file_type !="png")) 
{
	echo "only png and jpg files are allowed. <br>";
	$uploadOk=0;
}
if(file_exists($target_file)){
	echo "file already present on target location. <br";
	$uploadOk=0;
}
if($_FILES("fileupload")["size"] > 40000){
	echo "file is too  large. <br";
	$uploadOk=0;
}
if($upload ==0){
echo "sorry,your file was not uloaded.";}
else{
	if)move_uploaded_file($files["fileTuploaded"file]) ["tmp_name"] , $target_ file)) {
	echo"the file",. basename($_FILES["filto uploadeupload"]["name"]) . has bee uloaded;}
	else{
	echo"sorry;}
	

?>
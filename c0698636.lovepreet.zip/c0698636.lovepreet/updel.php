<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "c0698636_lovepreet";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

if(isset($_POST['update'])){
	$UpdateQuery = "UPDATE payroll SET id='$_POST[Id]', Name='$_POST[name]', Gender='$_POST[gender]' WHERE id='$_POST[hidden]'";
	mysql_query($UpdateQuery,$conn);
	
};


	if(isset($_POST['delete'])){
	$DeleteQuery = "DELETE FROM payroll  WHERE id='$_POST[hidden]'";
	mysql_query($DeleteQuery,$conn);


	};


	
	
	
	//mysql_select_db("698636_lovepreet",$conn);
$sql = "SELECT * FROM payroll";
//$myData = mysql_query($sql,$conn);
$result = $conn->query($sql);



//if ($result->num_rows > 0) {
    // output data of each row
    echo "<table border=1>
	<tr>
	<th>Id</th>
	<th>Name</th>
	<th>Gender</th>
	<th>Address</th>
	<th>Birth_date</th>
	<th>City</th>
	<th>Province</th>
	<th>Postalcode</th>
	<th>EmailAddress</th>
	<th>WebsiteLink</th>
	<th>JoiningDate</th>
	<th>AnnualBasicPay</th>
	</tr>";

    while($row = $result->fetch_assoc()) {
		echo "<form action=updel.php method=post>";
		echo "<tr>";
		echo "<td>" . "<input type=text name=Id value=" . $row['id'] . " </td>";
		echo "<td>" . "<input type=text name=name value=" . $row['Name'] . " </td>";
		echo "<td>" . "<input type=text name=gender value=" . $row['Gender'] . " </td>";
	    echo "<td>" . "<input type=hidden name=hidden value=" . $row['id'] . " </td>";
		echo "<td>" . "<input type=submit name=update value=update" . " </td>";
			echo "<td>" . "<input type=submit name=delete value=delete" . " </td>";
			echo "</tr>";
		
		
     echo "</form>";   
    }
    echo "</table>";
/*else {
 //  echo "0 results";
//}
*/
$conn->close();
?>
<html>
<head>
<title>Employee history</title>
</html>
 <?php
$servername = "localhost";
$username = "root";
$password = "";

// Create connection
$conn = new mysqli($servername, $username, $password);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
} 
echo "Connected successfully";


/*// Create database
$sql = "CREATE DATABASE c0698636_lovepreet";
if ($conn->query($sql) === TRUE) {
    echo "Database created successfully";
} else {
    echo "Error creating database: " . $conn->error;
}*/


// use database
$sql = "USE c0698636_lovepreet";
if ($conn->query($sql) === TRUE) {
    echo "Database created successfully";
} else {
    echo "Error creating database: " . $conn->error;
}

//sql to create table
$sql = "CREATE TABLE payroll (
id INT(6) UNSIGNED AUTO_INCREMENT PRIMARY KEY,
Name VARCHAR(50) ,
Gender VARCHAR(50) ,
Address VARCHAR(50),
Birth_date VARCHAR(50),
City VARCHAR(50),
Province VARCHAR(50),
Postalcode VARCHAR(50),
EmailAddress VARCHAR(50),
WebsiteLink VARCHAR(50),
AnnualBasicPay FLOAT
)";

if ($conn->query($sql) === TRUE) {
    echo "Table payroll created successfully";
} else {
    echo "Error creating table: " . $conn->error;
}



$sql = "INSERT INTO payroll(id,Name,Gender,Address,Birth_Date,City,Province,Postalcode,EmailAddress,WebsiteLink,JoiningDate,AnnualBasicPay)
VALUES(1,'LOVEPREET','Female','5 SHADOWOOD','1995/5/10','SCARBOROUGH','Ontario','1A1A1A' , 'lavi@gmail.com', 'www.fb.com', '2017/04/10','5000')";

$sql = "INSERT INTO payroll(id,Name,Gender,Address,Birth_Date,City,Province,Postalcode,EmailAddress,WebsiteLink,JoiningDate,AnnualBasicPay)
VALUES(2,'amrit','Female','17 sea cres drive','1995/05/14','Brampton','Ontario','1C1A1B' , 'aman@gmail.com', 'www.w3school.com', '2017/08/16','8000')";
 
$sql = "INSERT INTO payroll(id,Name,Gender,Address,Birth_Date,City,Province,Postalcode,EmailAddress,WebsiteLink,JoiningDate,AnnualBasicPay)
VALUES(3,'jaspreet','Female','19 parkside drive','1995/06/19','toronto','Ontario','2C4B6K' , 'lavi@gmail.com', 'www.yahoo.com', '2015/09/16','9000')";

$sql = "INSERT INTO payroll(id,Name,Gender,Address,Birth_Date,City,Province,Postalcode,EmailAddress,WebsiteLink,JoiningDate,AnnualBasicPay)
VALUES(4,'aman','Female','19 avenue drive','1995/07/18','toronto','Ontario','2G4G6K' , 'jassi@gmail.com', 'www.gmail.com', '2015/05/16','6000')";



$sql = "INSERT INTO payroll(id,Name,Gender,Address,Birth_Date,City,Province,Postalcode,EmailAddress,WebsiteLink,JoiningDate,AnnualBasicPay)
VALUES(5,'bikram','Female','19 parkside drive','1995/06/19','toronto','Ontario','2C4B6K' , 'lavi@gmail.com', 'www.yahoo.com', '2015/09/16','9000')";


$sql = "INSERT INTO payroll(id,Name,Gender,Address,Birth_Date,City,Province,Postalcode,EmailAddress,WebsiteLink,JoiningDate,AnnualBasicPay)
VALUES(6,'jyoti','Female','19 parkside drive','1995/06/19','toronto','Ontario','2C4B6K' , 'lavi@gmail.com', 'www.yahoo.com', '2015/09/16','9000')";
$sql = "INSERT INTO payroll(id,Name,Gender,Address,Birth_Date,City,Province,Postalcode,EmailAddress,WebsiteLink,JoiningDate,AnnualBasicPay)
VALUES(7,'chaht','Female','19 parkside drive','1995/06/19','toronto','Ontario','2C4B6K' , 'lavi@gmail.com', 'www.yahoo.com', '2015/09/16','9000')";
$sql = "INSERT INTO payroll(id,Name,Gender,Address,Birth_Date,City,Province,Postalcode,EmailAddress,WebsiteLink,JoiningDate,AnnualBasicPay)
VALUES(8,'preeti','Female','19 parkside drive','1995/06/19','toronto','Ontario','2C4B6K' , 'lavi@gmail.com', 'www.yahoo.com', '2015/09/16','9000')";
$sql = "INSERT INTO payroll(id,Name,Gender,Address,Birth_Date,City,Province,Postalcode,EmailAddress,WebsiteLink,JoiningDate,AnnualBasicPay)
VALUES(9,'navleen','Female','19 parkside drive','1995/06/19','toronto','Ontario','2C4B6K' , 'lavi@gmail.com', 'www.yahoo.com', '2015/09/16','9000')";
$sql = "INSERT INTO payroll(id,Name,Gender,Address,Birth_Date,City,Province,Postalcode,EmailAddress,WebsiteLink,JoiningDate,AnnualBasicPay)
VALUES(10,'vipan','Female','19 parkside drive','1995/06/19','toronto','Ontario','2C4B6K' , 'lavi@gmail.com', 'www.yahoo.com', '2015/09/16','9000')";
$sql = "INSERT INTO payroll(id,Name,Gender,Address,Birth_Date,City,Province,Postalcode,EmailAddress,WebsiteLink,JoiningDate,AnnualBasicPay)
VALUES(11,'nav','Female','19 parkside drive','1995/06/19','toronto','Ontario','2C4B6K' , 'lavi@gmail.com', 'www.yahoo.com', '2015/09/16','9000')";
$sql = "INSERT INTO payroll(id,Name,Gender,Address,Birth_Date,City,Province,Postalcode,EmailAddress,WebsiteLink,JoiningDate,AnnualBasicPay)
VALUES(10,'surinder','Female','19 parkside drive','1995/06/19','toronto','Ontario','2C4B6K' , 'lavi@gmail.com', 'www.yahoo.com', '2015/09/16','9000')";
$sql = "INSERT INTO payroll(id,Name,Gender,Address,Birth_Date,City,Province,Postalcode,EmailAddress,WebsiteLink,JoiningDate,AnnualBasicPay)
VALUES(12,'kulbir','Female','19 parkside drive','1995/06/19','toronto','Ontario','2C4B6K' , 'lavi@gmail.com', 'www.yahoo.com', '2015/09/16','9000')";




if ($conn->query($sql) === TRUE) {
    echo "New record created successfully";
} else {
    echo "Error: " . $sql . "<br>" . $conn->error;
}



$conn->close();
?>






<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "c0698636_lovepreet";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$sql = "SELECT * FROM payroll";
$result = $conn->query($sql);



if ($result->num_rows > 0) {
    // output data of each row
    echo "<table border=1>
	<tr>
	<th>Id</th>
	<th>Name</th>
	<th>Gender</th>
	<th>Address</th>
	<th>Birth_date</th>
	<th>City</th>
	<th>Province</th>
	<th>Postalcode</th>
	<th>EmailAddress</th>
	<th>WebsiteLink</th>
	<th>JoiningDate</th>
	<th>AnnualBasicPay</th>
	</tr>";
    while($row = $result->fetch_assoc()) {
		
		echo "<tr>";
		echo "<td>" . $row['id'] . "</td>";
		echo "<td>" . $row['Name'] . "</td>";
		echo "<td>" . $row['Gender'] . "</td>";
		echo "<td>" . $row['Address'] . "</td>";
		echo "<td>" . $row['Birth_date'] . "</td>";
		echo "<td>" . $row['City'] . "</td>";
		echo "<td>" . $row['Province'] . "</td>";
		echo "<td>" . $row['Postalcode'] . "</td>";
		echo "<td>" . $row['EmailAddress'] . "</td>";
		echo "<td>" . $row['WebsiteLink'] . "</td>";
		echo "<td>" . $row['WebsiteLink'] . "</td>";
		echo "<td>" . $row['AnnualBasicPay'] . "</td>";
		echo "</tr>";
        //echo "<tr><td>". $row["id"] . "</td><td>" . $row["Name"] . "</td><td>" . $row["Address"]. "</td></tr>";
    }
    echo "</table>";
} else {
    echo "0 results";
}
$conn->close();
?>